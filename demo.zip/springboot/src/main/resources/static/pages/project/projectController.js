app.controller("projectController",["$scope",function($scope){
	$scope.msg = "Project Controller";
}]);