app.controller("contactController",["$scope",function($scope){
	$scope.msg = "Contact Controller";
}]);