app.controller("serviceController",["$scope",function($scope){
	$scope.msg = "Service Controller";
}]);