app.controller("homeController",["$scope", function($scope){
	$scope.msg = "Home Controller";
}]);