app.controller("downloadController",["$scope",function($scope){
	$scope.msg = "Download Controller";
}]);