app.controller("aboutController",["$scope",function($scope){
	$scope.msg = "About Controller";
}]);